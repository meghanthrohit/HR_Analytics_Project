# HR Analytics – Employee Attrition Prediction

This is a full machine learning project that predicts employee attrition using HR data.

## Contents
- Data Preprocessing
- EDA
- ML Models (Logistic Regression, Random Forest)
- Feature Importance
- Final Reports

## Tools Used
Python, Pandas, Matplotlib, Seaborn, Scikit-Learn
